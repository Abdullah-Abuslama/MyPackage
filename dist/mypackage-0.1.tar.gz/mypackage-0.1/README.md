# mypackage
this library made as an example of how to publish your own python package.

# how to install
....